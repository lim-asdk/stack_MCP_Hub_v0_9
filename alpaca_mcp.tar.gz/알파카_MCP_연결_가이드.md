# 💎 알파카 MCP (Unified Hub) 연결 가이드

본 문서는 Alpaca MCP 스택을 다양한 환경(IDE, 터미널, 웹)에서 연결하여 사용하는 방법을 설명합니다.

---

## 1. 📂 프로젝트 구조
- **Core Server**: `mcp_hub/server.py` (모든 도구의 로직과 메타데이터가 집약된 핵심 서버)
- **Launchers**:
  - `mcp_hub/launch_stdio.py`: 표준 입출력(stdio) 방식 (IDE용)
  - `mcp_hub/launch_sse.py`: HTTP/SSE 방식 (웹 및 원격용)
  - `ui/Web_App_Launcher.py`: 전용 웹 브라우저 UI
  - `ui/Desktop_Launcher.py`: 전용 데스크톱 앱 UI

---

## 2. 🔌 연결 방법

### A. 로컬 (stdio) 방식 (가장 추천)
IDEs나 챗봇 프로그램 프로젝트에서 직접 연결할 때 사용합니다. 슬래시(`/`)를 사용하여 경로 호환성을 높였습니다.

- **명령 (Command)**: 아래 한 줄을 그대로 복사해서 사용하세요.
```powershell
C:/program_files/.venv/Scripts/python.exe C:/program_files/server/cells_apply/alpaca_mcp_v1/mcp_hub/launch_stdio.py
```

### B. HTTP/SSE 방식 (포트 8011)
표준 HTTP 프로토콜을 사용하여 MCP 서버에 접근할 때 사용합니다. 타 프로젝트와의 충돌을 피하기 위해 **8011**번 포트를 고정으로 사용합니다.

1. 서버 실행: `python mcp_hub/launch_sse.py`
2. 엔드포인트: `http://localhost:8011/sse`

### C. 전용 UI 실행 (모니터링용)
- **브라우저 전용**: `python ui/Web_App_Launcher.py` (포트 6991)
- **데스크톱 전용**: `python ui/Desktop_Launcher.py` (독립 창 앱)

---

## 🛠️ 주요 특징
- **포트 8011 고정**: `uvicorn`을 통해 강제로 8011번 포트를 할당하여 안정성을 높였습니다.
- **백그라운드 인덱싱**: 모든 런처(UI, SSE)가 시작 시 백그라운드에서 도구를 미리 로드하므로 접속이 빠릅니다.
- **맞춤형 테스트 데이터**: 각 셀(tool) 폴더 내에 `sample_input.json` 파일을 두면 UI(6991 포트)에서 해당 데이터가 자동으로 기본값으로 채워집니다.

---

## 🔒 보안 및 설정 (개인 키)
알파카 API 키는 다음 경로에서 자동으로 탐색됩니다:
1. `C:\program_files\grace\config_grace_apis.json` (중앙 관리 경로)
2. `[프로젝트루트]\config\config_grace_apis.json` (로컬 경로)

*제작: Antigravity (Advanced Agentic Coding Team)*
