# ..

import os
import sys
import json
import asyncio
import threading
import webbrowser
from pathlib import Path
from bottle import Bottle, request, response, static_file

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from mcp_hub import server

app = Bottle()
UI_DIR = Path(__file__).resolve().parent
PORT = 6991

@app.hook('after_request')
def enable_cors():
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'PUT, GET, POST, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'

@app.get("/")
def serve_index():
    """Serves the main Diagnostic UI (index.html)."""
    return static_file("index.html", root=UI_DIR)

@app.get("/api/tools")
def get_tools():
    """Returns the list of all indexed tool names."""
    return {"tools": server.get_all_tool_names()}

@app.get("/api/metadata/<name>")
def get_tool_metadata(name):
    """
    Returns metadata (description, sample_input) for a specific tool.
    Matched to index.html Line 374: fetch('/api/metadata/...')
    """
    return server.get_tool_metadata(name)

@app.get("/api/tools/<name>/metadata")
def get_tool_metadata_legacy(name):
    """Legacy route for metadata compatibility."""
    return server.get_tool_metadata(name)

@app.route('/api/call', method='POST')
def call_tool():
    idx = request.json or {}
    tool_name = idx.get("tool_name") or idx.get("tool")
    symbol = idx.get("symbol") or idx.get("input")
    
    try:
        # Robust async run for synchronous Bottle environment
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(server.execute_cell_worker(tool_name, symbol))
            return result
        finally:
            loop.close()
    except Exception as e:
        return {"ok": False, "error": f"Bridge Error: {str(e)}"}

if __name__ == "__main__":
    url = f"http://127.0.0.1:{PORT}/?v=1"
    print(f"=== Alpaca MCP Web Hub (Unified) Running on {url} ===")
    
    # Pre-build tool index in background to avoid hanging the first UI request
    print("[SYSTEM] Initializing tool index in background...")
    threading.Thread(target=server.get_all_tool_names, daemon=True).start()
    
    # Non-blocking browser launch
    threading.Timer(2.0, lambda: webbrowser.open_new(url)).start()
    
    # Bind to 127.0.0.1
    app.run(host='127.0.0.1', port=PORT, debug=True, reloader=False)
