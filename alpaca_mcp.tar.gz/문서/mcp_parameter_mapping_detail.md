# MCP 파라미터 통합 기술 상세 가이드: Redundant Injection & Schema Discovery

이 문서는 ASDK V6의 718개 서로 다른 모듈(날씨, 뉴스, 주식 등)을 어떻게 하나의 인터페이스로 통합했는지에 대한 핵심 기술 매뉴얼입니다.

---

## 1. 중복 주입 기법 (Redundant Injection Method)

### 개요: "고민하지 않고 모든 가능성을 열어둔다"
사용자가 입력한 단 하나의 값을, 서버는 해당 셀이 취할 수 있는 **모든 매개변수 이름**으로 복제하여 전달합니다.

### 작동 로직 (Core Logic):
사용자가 UI에서 `input: "NVDA"`를 던졌을 때, 서버 내부 메모리에서는 다음과 같은 **방송(Broadcasting)** 프로세스가 일어납니다.

```python
# 서버 내부의 파라미터 보정 계층 (Normalization Layer)
input_val = params.get("user_input") 

# 그물망식 중복 주입
params["symbol"]  = input_val  # 주식 셀용
params["symbols"] = input_val  # 다중 주식 셀용
params["ticker"]  = input_val  # 티커 전용 셀용
params["query"]   = input_val  # 뉴스 검색 셀용
params["text"]    = input_val  # 유틸리티/텍스트 처리용
```

### 왜 이 방법을 쓰는가?
- **호환성 100%**: A 셀은 `ticker`를 쓰고 B 셀은 `symbol`을 쓸 때, 서버가 둘 다 넣어줌으로써 어떤 셀도 에러 없이 작동합니다.
- **설정 제로**: 718개 셀 하나하나의 코드를 수정할 필요가 없습니다. 서버 입구에서만 처리하면 됩니다.
- **성능 최적화**: 메모리(RAM) 상의 텍스트 복사는 물리적 디스크 I/O에 비해 속도가 **무한대에 가깝게 빠릅니다.**

---

## 2. 스키마 기반 자동 발견 (Schema-based Auto Discovery)

### 개요: "전수 조사를 통한 지능형 인덱싱"
서버가 718개의 폴더를 하나씩 뒤지며 각 도구의 **'명함(Schema)'**을 분석하여 AI에게 직접 리포팅합니다.

### 단계별 프로세스:
1. **재귀적 스캔 (Recursive Scanning)**:
   - 서버 기동 시 `cells/` 하위의 모든 폴더를 탐색합니다.
   - `option_schema.json` 파일이 발견되면 유효한 도구로 식별합니다.

2. **명세 분석 (Parameter Analysis)**: 
   - 스키마 파일 안의 `input_schema` 섹션을 읽습니다.
   - 예: `room_api_open_meteo` 셀의 경우 `lat`(위도), `lon`(경도)이 필수인 것을 서버가 메모리에 기억합니다.

3. **AI 명세서 자동 생성 (Dynamic Tool Registration)**:
   - 분석된 정보(도구 이름, 설명, 필요한 파라미터 목록)를 바탕으로 AI(LLM)에게 도구 목록을 전송합니다.
   - AI는 이를 보고 **"아, 이 날씨 도구는 좌표가 필요하구나"**라고 스스로 판단하여 좌표 데이터를 생성하게 됩니다.

---

## 3. 구조적 시너지

| 기법 | 역할 | 결과 |
| :--- | :--- | :--- |
| **Redundant Injection** | 입력 규격의 통일 | 사용자 편의성 극대화 (아무거나 넣어도 됨) |
| **Schema Discovery** | 출력 및 호출 규격의 정의 | AI 지능형 연동 (복잡한 매개변수 처리 가능) |

### 결론:
이 두 기법의 결합을 통해, **수백 개의 복잡한 폴더와 수천 개의 변수명**은 사용자에게 **단 하나의 직관적인 입력창**으로 단순화되었습니다. 이것이 ASDK가 수백 배의 반응 속도와 관리 편의성을 동시에 잡은 기술적 배경입니다.
