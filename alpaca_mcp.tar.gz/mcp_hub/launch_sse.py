import sys
import os
from pathlib import Path

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from mcp_hub.server import register_all_tools, mcp

if __name__ == "__main__":
    PORT = 8011
    print(f"=== Alpaca MCP Hub (SSE/HTTP Port) Starting on http://localhost:{PORT} ===", file=sys.stderr)
    register_all_tools()
    
    # Use uvicorn directly with mcp.sse_app to ensure the port is respected
    import uvicorn
    uvicorn.run(mcp.sse_app, host="127.0.0.1", port=PORT)
